import server from "./index.js";

server.listen(3000, () => {
  console.log(`server is listening at port 3000`);
});
